import React, { useMemo, useState } from 'react';
import { Link, NavLink, Route, Routes, useNavigate } from 'react-router-dom';
import * as XLSX from 'xlsx';
import {
  ArrowRight,
  Check,
  Download,
  Edit3,
  FileSpreadsheet,
  Home,
  LayoutDashboard,
  MapPinned,
  ShieldCheck,
  Trash2,
  Upload,
} from 'lucide-react';

const REQUIRED_COLUMNS = [
  'Serial Number',
  'Asset Name',
  'Asset Description',
  'Fiscal Year',
  'Department',
  'Asset Category',
  'Amount',
];

const REQUEST_STEPS = [
  'Requester',
  'Head of Department',
  'Director HR/Admin',
  'Finance Head',
  'VP Strategy',
  'Finance Accountant',
];

const REQUEST_HISTORY = [
  {
    id: 'REQ-1001',
    shortDescription: 'Office chair purchase',
    requestedDate: '2026-05-22',
    status: 'Pending for HOD approval',
    progress: 1,
    mode: 'active',
  },
  {
    id: 'REQ-1002',
    shortDescription: 'Printer toner supply',
    requestedDate: '2026-05-28',
    status: 'Pending for Director HR/Admin approval',
    progress: 2,
    mode: 'active',
  },
  {
    id: 'REQ-1003',
    shortDescription: 'Laptop upgrade batch',
    requestedDate: '2026-06-01',
    status: 'Pending for Finance head approval',
    progress: 3,
    mode: 'active',
  },
  {
    id: 'REQ-1004',
    shortDescription: 'Security camera replacement',
    requestedDate: '2026-06-04',
    status: 'Pending for VP Strategy approval',
    progress: 4,
    mode: 'active',
  },
  {
    id: 'REQ-1005',
    shortDescription: 'Reception desk renovation',
    requestedDate: '2026-06-07',
    status: 'Declined',
    progress: 5,
    mode: 'declined',
  },
  {
    id: 'REQ-1006',
    shortDescription: 'Vehicle tracker devices',
    requestedDate: '2026-06-10',
    status: 'Complete',
    progress: 6,
    mode: 'complete',
  },
];

const sampleLandingCards = [
  {
    title: 'Asset Requisition',
    text: 'Download the template, upload requisition lines and submit your request.',
    to: '/asset-requisition',
    icon: FileSpreadsheet,
  },
  {
    title: 'Requisition Tracking',
    text: 'Open request history and inspect each approval timeline.',
    to: '/requisition-tracking',
    icon: ShieldCheck,
  },
  {
    title: 'Report Creation',
    text: 'Reserved for budget utilization reports and category-wise analysis.',
    to: '/report-creation',
    icon: LayoutDashboard,
  },
];

function App() {
  const [rows, setRows] = useState([]);
  const [banner, setBanner] = useState('');

  return (
    <div className="app-shell">
      <Header />
      {banner ? <div className="global-banner">{banner}</div> : null}
      <main className="page-shell">
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route
            path="/asset-requisition"
            element={
              <AssetRequisitionPage
                rows={rows}
                setRows={setRows}
                setBanner={setBanner}
              />
            }
          />
          <Route path="/requisition-tracking" element={<RequisitionTrackingPage />} />
          <Route path="/report-creation" element={<ReportsPage />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}

function Header() {
  return (
    <header className="site-header">
      <div className="header-inner">
        <Link to="/" className="brand-block" aria-label="MuntQ home">
          <div className="brand-logo-wrap">
            <img
              src="/muntq-logo.svg"
              alt="MuntQ logo"
              className="brand-logo"
              onError={(event) => {
                event.currentTarget.style.display = 'none';
                const fallback = event.currentTarget.nextElementSibling;
                if (fallback) fallback.style.display = 'inline-flex';
              }}
            />
            <div className="brand-fallback" style={{ display: 'none' }}>M</div>
          </div>
          <div>
            <div className="brand-title">MuntQ</div>
            <div className="brand-subtitle">Asset Requisition Portal</div>
          </div>
        </Link>

        <nav className="top-nav" aria-label="Primary navigation">
          <NavItem to="/" label="Home" />
          <NavItem to="/asset-requisition" label="Asset Requisition" />
          <NavItem to="/requisition-tracking" label="Requisition Tracking" />
          <NavItem to="/report-creation" label="Report Creation" />
        </nav>
      </div>
    </header>
  );
}

function NavItem({ to, label }) {
  return (
    <NavLink
      to={to}
      className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}
    >
      {label}
    </NavLink>
  );
}

function Footer() {
  return (
    <footer className="site-footer">
      <div className="footer-inner">
        <div>© 2026 MuntQ Asset Management</div>
        <div className="footer-note">Premium requisition workflow experience</div>
      </div>
    </footer>
  );
}

function HeroPanel({ title, description, actions, eyebrow = 'MUNTQ WORKSPACE' }) {
  return (
    <section className="hero-panel">
      <div className="hero-copy">
        <div className="eyebrow">{eyebrow}</div>
        <h1>{title}</h1>
        <p>{description}</p>
        {actions ? <div className="hero-actions">{actions}</div> : null}
      </div>
      <div className="hero-metrics">
        <div className="metric-card accent">
          <span>Budget Visibility</span>
          <strong>Live</strong>
        </div>
        <div className="metric-card">
          <span>Approval Route</span>
          <strong>6 Steps</strong>
        </div>
        <div className="metric-card">
          <span>Design Theme</span>
          <strong>Premium Green</strong>
        </div>
      </div>
    </section>
  );
}

function LandingPage() {
  return (
    <div className="page-grid">
      <HeroPanel
        title="A unified, professional workspace for asset requests"
        description="Start a requisition, track approvals and move into reporting while keeping the same polished green-and-white experience across every screen."
        actions={
          <>
            <Link className="primary-button" to="/asset-requisition">
              Start Requisition <ArrowRight size={18} />
            </Link>
            <Link className="secondary-button" to="/requisition-tracking">
              Track Requests
            </Link>
          </>
        }
      />

      <section className="content-card landing-card-grid">
        {sampleLandingCards.map((item) => {
          const Icon = item.icon;
          return (
            <Link to={item.to} key={item.title} className="landing-card">
              <div className="landing-icon"><Icon size={22} /></div>
              <h3>{item.title}</h3>
              <p>{item.text}</p>
              <span className="card-link">Open <ArrowRight size={16} /></span>
            </Link>
          );
        })}
      </section>
    </div>
  );
}

function AssetRequisitionPage({ rows, setRows, setBanner }) {
  const navigate = useNavigate();
  const [editingRowId, setEditingRowId] = useState(null);
  const [draftRows, setDraftRows] = useState({});
  const [uploadMessage, setUploadMessage] = useState('');

  const handleDownloadTemplate = () => {
    const workbook = XLSX.utils.book_new();
    const worksheet = XLSX.utils.aoa_to_sheet([REQUIRED_COLUMNS]);
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Asset Requisition');
    XLSX.writeFile(workbook, 'muntq-asset-requisition-template.xlsx');
    setUploadMessage('Template downloaded successfully.');
    setBanner('Template ready. You can fill it later and upload the Excel file anytime.');
  };

  const sanitizeRow = (item) => {
    const normalized = {};
    REQUIRED_COLUMNS.forEach((column) => {
      normalized[column] = item[column] ?? item[column.toLowerCase()] ?? '';
    });
    return {
      id: crypto.randomUUID(),
      ...normalized,
    };
  };

  const handleFileUpload = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const buffer = await file.arrayBuffer();
      const workbook = XLSX.read(buffer, { type: 'array' });
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      const jsonRows = XLSX.utils.sheet_to_json(sheet, { defval: '' });
      const cleanedRows = jsonRows
        .map(sanitizeRow)
        .filter((row) => REQUIRED_COLUMNS.some((column) => String(row[column]).trim() !== ''));

      if (!cleanedRows.length) {
        setUploadMessage('No valid line items were found in the uploaded file.');
        return;
      }

      setRows((current) => [...current, ...cleanedRows]);
      setUploadMessage(`File uploaded successfully. ${cleanedRows.length} line item(s) added.`);
      setBanner(`Upload successful. The new requisition lines were added below the existing items.`);
      event.target.value = '';
    } catch (error) {
      setUploadMessage('The file could not be processed. Please use an Excel file with the required columns.');
    }
  };

  const startEdit = (row) => {
    setEditingRowId(row.id);
    setDraftRows((current) => ({ ...current, [row.id]: { ...row } }));
  };

  const updateDraftCell = (rowId, column, value) => {
    setDraftRows((current) => ({
      ...current,
      [rowId]: {
        ...current[rowId],
        [column]: value,
      },
    }));
  };

  const saveEdit = (rowId) => {
    setRows((current) => current.map((row) => (row.id === rowId ? { ...draftRows[rowId] } : row)));
    setEditingRowId(null);
    setUploadMessage('Line item updated successfully.');
  };

  const deleteRow = (rowId) => {
    setRows((current) => current.filter((row) => row.id !== rowId));
    if (editingRowId === rowId) {
      setEditingRowId(null);
    }
    setUploadMessage('Line item deleted successfully.');
  };

  const submitRequisition = () => {
    setBanner('Requisition submitted. You can now review the tracking history and approval timeline.');
    navigate('/requisition-tracking');
  };

  return (
    <div className="page-grid">
      <HeroPanel
        eyebrow="ASSET REQUISITION"
        title="Prepare, upload and review your requisition line items"
        description="Download the Excel guide if needed, upload one or multiple filled files and edit each row inline before submission."
      />

      <section className="content-card">
        <div className="section-heading-row">
          <div>
            <h2>Asset Requisition</h2>
            <p>Use the same structured format to bring requisition lines into the system.</p>
          </div>
          <div className="toolbar-row">
            <button className="secondary-button" onClick={handleDownloadTemplate}>
              <Download size={18} /> Download Template
            </button>
            <label className="primary-button upload-button">
              <Upload size={18} /> Upload Excel
              <input type="file" accept=".xlsx,.xls" onChange={handleFileUpload} />
            </label>
          </div>
        </div>

        {uploadMessage ? <div className="success-message">{uploadMessage}</div> : null}

        <div className="table-scroll table-space-top">
          <table className="data-table">
            <thead>
              <tr>
                {REQUIRED_COLUMNS.map((column) => (
                  <th key={column}>{column}</th>
                ))}
                <th className="actions-col">&nbsp;</th>
              </tr>
            </thead>
            <tbody>
              {rows.length ? (
                rows.map((row) => {
                  const isEditing = editingRowId === row.id;
                  const source = isEditing ? draftRows[row.id] ?? row : row;
                  return (
                    <tr key={row.id}>
                      {REQUIRED_COLUMNS.map((column) => (
                        <td key={`${row.id}-${column}`}>
                          {isEditing ? (
                            <input
                              className="cell-input"
                              value={source[column] ?? ''}
                              onChange={(event) => updateDraftCell(row.id, column, event.target.value)}
                            />
                          ) : (
                            <span>{source[column]}</span>
                          )}
                        </td>
                      ))}
                      <td className="row-actions">
                        <button
                          className="icon-button"
                          aria-label={isEditing ? 'Save row' : 'Edit row'}
                          onClick={() => (isEditing ? saveEdit(row.id) : startEdit(row))}
                        >
                          {isEditing ? <Check size={18} /> : <Edit3 size={18} />}
                        </button>
                        <button
                          className="icon-button danger"
                          aria-label="Delete row"
                          onClick={() => deleteRow(row.id)}
                        >
                          <Trash2 size={18} />
                        </button>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={REQUIRED_COLUMNS.length + 1}>
                    <div className="empty-state-inline">
                      No line items yet. Upload an Excel file to view your requisition lines here.
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="submit-row">
          <button className="primary-button" onClick={submitRequisition} disabled={!rows.length}>
            Submit Requisition <ArrowRight size={18} />
          </button>
        </div>
      </section>
    </div>
  );
}

function RequisitionTrackingPage() {
  const [selectedRequestId, setSelectedRequestId] = useState(REQUEST_HISTORY[0].id);
  const selectedRequest = useMemo(
    () => REQUEST_HISTORY.find((request) => request.id === selectedRequestId) || REQUEST_HISTORY[0],
    [selectedRequestId]
  );

  return (
    <div className="page-grid">
      <HeroPanel
        eyebrow="REQUISITION TRACKING"
        title="Inspect request history and each approval timeline"
        description="Select any request ID to load the specific workflow progress below the history table."
      />

      <section className="content-card">
        <div className="section-heading-row compact">
          <div>
            <h2>Request History</h2>
            <p>Click a request ID to reveal its exact approval state.</p>
          </div>
        </div>

        <div className="table-scroll">
          <table className="data-table tracking-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Short Description</th>
                <th>Requested Date</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {REQUEST_HISTORY.map((request) => (
                <tr key={request.id} className={request.id === selectedRequestId ? 'selected-row' : ''}>
                  <td>
                    <button
                      className="inline-link-button"
                      onClick={() => setSelectedRequestId(request.id)}
                    >
                      {request.id}
                    </button>
                  </td>
                  <td>{request.shortDescription}</td>
                  <td>{request.requestedDate}</td>
                  <td>
                    <span className={`status-badge ${badgeClassForStatus(request.mode)}`}>{request.status}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <p className="tracking-helper">Your request is here:</p>

        <ApprovalTimeline request={selectedRequest} />
      </section>
    </div>
  );
}

function badgeClassForStatus(mode) {
  if (mode === 'complete') return 'badge-complete';
  if (mode === 'declined') return 'badge-declined';
  return 'badge-pending';
}

function ApprovalTimeline({ request }) {
  const lineClass = request.mode === 'declined' ? 'timeline-line declined' : request.mode === 'complete' ? 'timeline-line complete' : 'timeline-line';
  return (
    <div className="timeline-shell">
      <div className="timeline-scroll">
        <div className="timeline-track">
          <div className={lineClass} />
          {REQUEST_STEPS.map((label, index) => {
            const stepIndex = index + 1;
            const isFilled = stepIndex <= request.progress;
            const circleClasses = ['timeline-circle'];
            if (request.mode === 'declined') circleClasses.push('declined');
            if (request.mode === 'complete') circleClasses.push('complete');
            if (isFilled) circleClasses.push('filled');

            const labelClasses = ['timeline-label'];
            if (request.mode === 'declined') labelClasses.push('declined');
            if (request.mode === 'complete') labelClasses.push('complete');

            return (
              <div className="timeline-step" key={label}>
                <div className={circleClasses.join(' ')} aria-hidden="true" />
                <div className={labelClasses.join(' ')}>{label}</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function ReportsPage() {
  return (
    <div className="page-grid">
      <HeroPanel
        eyebrow="REPORT CREATION"
        title="Category-wise budget reporting is reserved for the next phase"
        description="The final interactive reporting experience will be added on this screen while preserving the same premium design system."
      />

      <section className="content-card coming-soon-card">
        <div className="coming-soon-icon"><MapPinned size={28} /></div>
        <h2>Coming Soon</h2>
        <p>
          This page is intentionally prepared with the correct theme and structure so the report creation features can be added later without changing the overall experience.
        </p>
      </section>
    </div>
  );
}

export default App;
